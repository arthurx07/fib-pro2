var searchData=
[
  ['necesita_0',['necesita',['../structCiudad_1_1Atributos.html#ab6da06f3809adbb764b301750df12329',1,'Ciudad::Atributos']]]
];
