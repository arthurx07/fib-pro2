var searchData=
[
  ['agregar_5fproducto_0',['agregar_producto',['../classCuenca.html#a1bc627f8ce94cbe917dfe76251a32e83',1,'Cuenca']]],
  ['agregar_5fviaje_1',['agregar_viaje',['../classBarco.html#ac9118295ea0e9969b90568480c45c267',1,'Barco']]]
];
