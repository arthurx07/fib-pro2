var searchData=
[
  ['hacer_5fviaje_0',['hacer_viaje',['../classCuenca.html#a84842eab031c4fc71179fe2191e0dad9',1,'Cuenca']]]
];
