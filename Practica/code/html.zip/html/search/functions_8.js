var searchData=
[
  ['poner_5fprod_0',['poner_prod',['../classCuenca.html#a557ddb75516bca82111b055c5d0b042b',1,'Cuenca']]],
  ['poner_5fproducto_1',['poner_producto',['../classCiudad.html#a0645a6def9d4a2f31abca4fa4983b4d2',1,'Ciudad']]],
  ['producto_2',['producto',['../classProducto.html#abdf37557185a4660251488b2db47fc7d',1,'Producto::Producto()'],['../classProducto.html#a17c534ba49282c22547ef5f41a46c89d',1,'Producto::Producto(int id, int peso, int volumen)']]]
];
