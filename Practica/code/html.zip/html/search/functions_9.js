var searchData=
[
  ['quitar_5fprod_0',['quitar_prod',['../classCuenca.html#a0eefe8481557bb1d80bdef3807343271',1,'Cuenca']]],
  ['quitar_5fproducto_1',['quitar_producto',['../classCiudad.html#a99db0ddd81eb9df4b1531ef11806da51',1,'Ciudad']]]
];
