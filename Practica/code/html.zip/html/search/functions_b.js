var searchData=
[
  ['size_0',['size',['../classCiudad.html#a835d370215b5e3d872a8bb31fb6c884a',1,'Ciudad']]]
];
