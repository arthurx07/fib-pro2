var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstv",
  1: "abcp",
  2: "bcp",
  3: "abcehlmopqrst",
  4: "bceinpv",
  5: "o",
  6: "acdfglp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Amigas",
  6: "Páginas"
};

