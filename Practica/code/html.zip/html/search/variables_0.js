var searchData=
[
  ['barco_0',['barco',['../classCuenca.html#aa7ff1a1213cd6361f46ea8438f495a9c',1,'Cuenca']]]
];
