var searchData=
[
  ['ciudades_0',['ciudades',['../classCuenca.html#a141967afc7cad3ac0fa075e13c217fea',1,'Cuenca']]],
  ['comprar_1',['comprar',['../classBarco.html#a2dd4ef30e47e90a4a48c493854137589',1,'Barco']]]
];
