var searchData=
[
  ['id_0',['id',['../classProducto.html#ac7e63125ce8671260d15e473e689efa4',1,'Producto']]],
  ['inventario_1',['inventario',['../classCiudad.html#ab8931e827eef3045e1897474d5efcb22',1,'Ciudad']]]
];
